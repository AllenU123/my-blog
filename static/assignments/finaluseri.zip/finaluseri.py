import subprocess
import sys

def check_ollama():
    try:
        result = subprocess.run(["ollama", "list"], 
                              check=True, 
                              stdout=subprocess.PIPE, 
                              stderr=subprocess.PIPE,
                              text=True)
        if "llama3" not in result.stdout:
            print("Warning: llama3 model not found in Ollama. Please install it with 'ollama pull llama3'")
    except FileNotFoundError:
        print("Error: Ollama is not installed. Please install it first from https://ollama.com/")
        sys.exit(1)
    except subprocess.CalledProcessError:
        print("Error: Ollama is not running. Please start the Ollama service.")
        sys.exit(1)

import streamlit as st
import subprocess
import ollama
import os
import sys
from pathlib import Path
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import tempfile
import shutil
import rasterio
import webbrowser

# ------------------------
# Page Config
# ------------------------
st.set_page_config(page_title="LLM-Assisted Flood Mapping", layout="wide")
st.title("🛰️ LLM-Assisted Flood Susceptibility Mapping Tool")

# ------------------------
# Sidebar Inputs
# ------------------------
st.sidebar.header("🗺️ Study Area Settings")
region_input_mode = st.sidebar.radio("Region Input Mode", ["Select", "Custom"])

if region_input_mode == "Select":
    predefined_regions = ["Rwanda", "Bangladesh", "India", "Germany", "Brazil"]
    selected_region = st.sidebar.selectbox("Select Region", predefined_regions)
else:
    selected_region = st.sidebar.text_input("Enter custom region name:", "Your Region")

dataset_options = ["DEM", "Rainfall", "Land Use", "NDVI", "Soil Type"]
selected_datasets = st.sidebar.multiselect("Select Datasets (DEM is required)", dataset_options, default=["DEM"])
time_range = st.sidebar.text_input("Time Range (e.g., 2020-2023)", "2021-2023")

# ------------------------
# File Uploads Section
# ------------------------
st.sidebar.markdown("---")
st.sidebar.header("📁 Upload Datasets")
uploaded_files = {}
for ds in dataset_options:
    uploaded_files[ds] = st.sidebar.file_uploader(f"Upload {ds} File", type=["tif", "tiff", "geotiff"], key=ds)

# ------------------------
# Data Processing Functions
# ------------------------
def save_uploaded_files(uploaded_files):
    saved_paths = {}
    upload_dir = Path("uploads")
    upload_dir.mkdir(exist_ok=True)
    
    for f in upload_dir.glob("*"):
        try:
            f.unlink()
        except Exception:
            pass
            
    for ds, file in uploaded_files.items():
        if file is not None:
            safe_name = "".join(c for c in file.name if c.isalnum() or c in (' ', '.', '_')).rstrip()
            save_path = upload_dir / safe_name
            with open(save_path, "wb") as f:
                f.write(file.getbuffer())
            saved_paths[ds] = str(save_path)
    return saved_paths

def process_uploaded_data(saved_paths):
    processed_data = {}
    for ds, path in saved_paths.items():
        if path and os.path.exists(path):
            try:
                with rasterio.open(path) as src:
                    data = src.read(1)
                    data = data.astype(np.float32)
                    if src.nodata is not None:
                        data[data == src.nodata] = np.nan
                    data_min = np.nanmin(data)
                    data_max = np.nanmax(data)
                    if data_max != data_min:
                        data_norm = (data - data_min) / (data_max - data_min)
                    else:
                        data_norm = np.zeros_like(data)
                    processed_data[ds] = data_norm
            except Exception as e:
                st.warning(f"Could not read {ds} file: {str(e)}")
                return None
    return processed_data if processed_data else None

def generate_synthetic_data(region, datasets, width=500, height=500):
    if "Rwanda" in region:
        elevation_params = {"loc": 1500, "scale": 300}
        rainfall_params = {"loc": 100, "scale": 40}
    elif "Bangladesh" in region:
        elevation_params = {"loc": 10, "scale": 5}
        rainfall_params = {"loc": 200, "scale": 60}
    else:
        elevation_params = {"loc": 500, "scale": 100}
        rainfall_params = {"loc": 100, "scale": 30}

    synthetic_data = {}
    
    if "DEM" in datasets:
        x = np.linspace(0, 10, width)
        y = np.linspace(0, 10, height)
        X, Y = np.meshgrid(x, y)
        base = np.random.normal(**elevation_params, size=(height, width))
        terrain = np.sin(X*1.5)*np.cos(Y*1.2)*50 + np.sin(X*0.5)*np.cos(Y*0.3)*20
        dem = base + terrain
        dem[dem < 0] = 0
        synthetic_data["DEM"] = dem
    
    if "Rainfall" in datasets:
        rainfall = np.random.normal(**rainfall_params, size=(height, width))
        rainfall = np.abs(rainfall)
        synthetic_data["Rainfall"] = (rainfall - rainfall.min()) / (rainfall.max() - rainfall.min())
    
    if "Land Use" in datasets:
        land_use = np.random.choice([0, 1, 2, 3], size=(height, width), p=[0.1, 0.4, 0.3, 0.2])
        synthetic_data["Land Use"] = land_use
    
    if "NDVI" in datasets:
        ndvi = np.random.uniform(-0.1, 0.9, size=(height, width))
        synthetic_data["NDVI"] = ndvi
    
    return synthetic_data

# ------------------------
# Script Generation Functions
# ------------------------
def generate_real_data_script(region, datasets, time_range):
    prompt = f"""Generate Python code for flood susceptibility mapping with:
- Region: {region}
- Time Range: {time_range}
- Available datasets: {datasets}

Important Requirements:
1. Load data using: data = np.load('processed_data.npz', allow_pickle=True)
2. Data is 2D numpy arrays
3. DEM should be inverted (lower elevation = higher risk)
4. Classify risk numerically: 1=Low (<0.3), 2=Moderate (0.3-0.7), 3=High (>=0.7)
5. Save output as 'flood_map.png'
6. Use only matplotlib for visualization
7. Do NOT use rasterio in this script
8. Dataset keys are capitalized: 'DEM', 'Rainfall', etc.

Output only the Python code between ```python ``` markers."""
    
    response = ollama.chat(model="llama3", messages=[{"role": "user", "content": prompt}])
    generated_code = response['message']['content']
    
    if '```python' in generated_code:
        generated_code = generated_code.split('```python')[1].split('```')[0]
    
    # Ensure correct file name and remove rasterio
    generated_code = generated_code.replace("processed_processed_data.npz", "processed_data.npz")
    generated_code = "\n".join([line for line in generated_code.split("\n") 
                              if not line.strip().startswith(("import rasterio", "with rasterio.open"))])
    
    # Add required imports
    required_imports = ["import numpy as np", "import matplotlib.pyplot as plt"]
    for imp in required_imports:
        if imp not in generated_code:
            generated_code = imp + "\n" + generated_code
    
    return generated_code

def generate_synthetic_script(region, datasets, time_range):
    # Create title without any special characters that might cause issues
    title = f"Flood Susceptibility Map - {region} ({time_range})"
    
    script = f"""# Flood Susceptibility Analysis for {region}
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import matplotlib.patches as mpatches

data = np.load('processed_data.npz', allow_pickle=True)
factors = {{}}
weights = {{}}
"""
    
    if "DEM" in datasets:
        script += """
dem = data["DEM"]
dem_norm = (np.nanmax(dem) - dem)/(np.nanmax(dem)-np.nanmin(dem))
factors["DEM"] = dem_norm
weights["DEM"] = 0.4
"""
    
    if "Rainfall" in datasets:
        script += """
factors["Rainfall"] = data["Rainfall"]
weights["Rainfall"] = 0.3
"""
    
    if "Land Use" in datasets:
        script += """
lu = data["Land Use"]
factors["Land Use"] = np.where(lu==0,0.9,np.where(lu==2,0.7,np.where(lu==3,0.5,0.3)))
weights["Land Use"] = 0.2
"""
    
    if "NDVI" in datasets:
        script += """
ndvi = data["NDVI"]
factors["NDVI"] = 1-((ndvi-np.nanmin(ndvi))/(np.nanmax(ndvi)-np.nanmin(ndvi)))
weights["NDVI"] = 0.1
"""
    
    script += f"""
total_weight = sum(weights.values())
flood_risk = sum(factors[f]*(weights[f]/total_weight) for f in factors)
flood_risk = np.nan_to_num(flood_risk, nan=0.0)

classified = np.zeros_like(flood_risk)
classified[flood_risk<0.3] = 1
classified[(flood_risk>=0.3)&(flood_risk<0.7)] = 2
classified[flood_risk>=0.7] = 3

fig, ax = plt.subplots(figsize=(12,10))
img = ax.imshow(classified, cmap=LinearSegmentedColormap.from_list("flood_risk", ["#2A788E","#79D151","#FDE725","#440154"]), 
                vmin=1, vmax=3, interpolation='bilinear')

legend = [mpatches.Patch(color=plt.cm.viridis(i/3), label=l) 
          for i,l in zip([1,2,3], ['Low','Moderate','High'])]
plt.legend(handles=legend, title='Flood Risk', bbox_to_anchor=(1.05,1), loc='upper left')

plt.colorbar(img, ticks=[1,2,3]).set_ticklabels(['Low','Moderate','High'])
plt.title('{title}')
plt.axis('off')
plt.tight_layout()
plt.savefig('flood_map.png', dpi=300, bbox_inches='tight')
plt.close()
"""
    return script

# ------------------------
# Main Execution
# ------------------------
if st.button("🚀 Generate Flood Map"):
    if not selected_region or not selected_datasets:
        st.warning("Please select at least one dataset (DEM is required).")
    else:
        if "DEM" not in selected_datasets:
            selected_datasets.append("DEM")
            
        with tempfile.TemporaryDirectory() as temp_dir:
            original_dir = os.getcwd()
            try:
                os.chdir(temp_dir)
                
                # Process data
                saved_paths = save_uploaded_files(uploaded_files)
                processed_data = process_uploaded_data(saved_paths) or generate_synthetic_data(selected_region, selected_datasets)
                np.savez("processed_data.npz", **processed_data)
                
                # Generate and run script
                script = generate_real_data_script(selected_region, selected_datasets, time_range) if any(saved_paths.values()) \
                        else generate_synthetic_script(selected_region, selected_datasets, time_range)
                
                with open("generated_script.py", "w", encoding='utf-8') as f:
                    f.write(script)
                
                result = subprocess.run([sys.executable, "generated_script.py"], 
                                      capture_output=True, text=True)
                
                if result.returncode == 0 and os.path.exists("flood_map.png"):
                    st.success("Flood susceptibility map generated successfully!")
                    col1, col2 = st.columns([3, 1])
                    with col1:
                        st.image(Image.open("flood_map.png"), use_column_width=True)
                    with col2:
                        with open("flood_map.png", "rb") as f:
                            st.download_button(
                                "Download Map", 
                                f, 
                                file_name=f"flood_map_{selected_region}.png",
                                mime="image/png"
                            )
                else:
                    st.error("Failed to generate map")
                    st.text(result.stderr)
                    
            except Exception as e:
                st.error(f"An error occurred: {str(e)}")
            finally:
                os.chdir(original_dir)

st.markdown("---")
st.markdown("**Flood Susceptibility Mapping Tool**  \n*Using LLM-assisted geospatial analysis*")

import streamlit as st
import ollama
import subprocess
import sys
import webbrowser

def check_ollama():
    try:
        result = subprocess.run(["ollama", "list"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=5)
        if "llama3" not in result.stdout and "llama2" not in result.stdout:
            print("Warning: Neither llama3 nor llama2 model found in Ollama. Ensure models are pulled with 'ollama pull llama3' or 'ollama pull llama2'.")
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
        print("Warning: Ollama may not be running or accessible. Ensure 'ollama serve' is started in another terminal.")

if __name__ == "__main__":
    check_ollama()
    if not st.runtime.exists():
        import streamlit.web.cli as stcli
        import os
        import sys
        print("Starting Streamlit server on http://localhost:8502...")  # Debug output
        print(f"Current sys.argv: {sys.argv}")  # Debug
        script_path = __file__  # This should resolve to the extracted script in temp dir
        if getattr(sys, 'frozen', False):  # Check if running as executable
            base_path = sys._MEIPASS
            script_path = os.path.join(base_path, os.path.basename(__file__))
        sys.argv = ["streamlit", "run", script_path, "--server.port", "8502", "--global.developmentMode", "false"]
        print(f"Modified sys.argv: {sys.argv}")  # Debug
        webbrowser.open('http://localhost:8502')  # Update URL
        sys.exit(stcli.main())